

// reading the pipa.json
function save_player_session(player_name, player_balance, current_timestamp) {
    const fs = require('fs');
    data = require("../pipa.json");
    console.log(`1st step testing:`);
    console.log(data);
    
    // if key "Game rounds" exists - pushing new value object
    if (data.hasOwnProperty("Game rounds")) {
        data["Game rounds"].push({"Player name":player_name,"Player balance":player_balance, "Current timestamp":current_timestamp});
        console.log(`2d step testing:`);
        console.log(data);
        const jsonData = JSON.stringify(data, null, 2);
        fs.writeFile("./pipa.json", jsonData, (err) => {
            if (err) {
                console.error('Error appending to the file:', err);
            }
            else {
                console.log('Data was successfully appended!');
            }
        });
    }

    // if key "Game rounds" is NOT exists - creating file structure
    else {
        let data = {["Game rounds"]: {["Player name"]: player_name, ["Player balance"]: player_balance, ["Current timestamp"]: current_timestamp}};
        const jsonData = JSON.stringify(data, null, 2);
        fs.writeFile("./pipa.json", jsonData, (err) => {
        if (err) {
            console.error('Error appending to the file:', err);
        }
        else {
            console.log('Data was successfully appended!');
        }
    });
    console.log(`3d step testing:`);
    console.log(data);
    }
    };


player_name_1 = "Yana";
plaer_balance_1 = 10;
current_timestamp_1 = 111;

save_player_session(player_name_1, plaer_balance_1, current_timestamp_1);