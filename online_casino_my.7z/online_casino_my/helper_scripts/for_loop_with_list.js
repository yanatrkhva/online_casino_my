
// for-in (iterates over keys(index of arrays))
// for-of (iterates over vaules(elements of arrays))




function find_index_of_an_element(animals_list, search_for_index_of) {
    for (let unknown_variable of animals_list) {
        if (unknown_variable === search_for_index_of) {
            return animals_list.indexOf(unknown_variable);
        }
    }
    return false;
}

const animals = ["Lion", "Elephant", "Giraffe", "Zebra", "Kangaroo", "Panda", "Dolphin", "Wolf"];

search_for_index_of = "Zebra1";

result = find_index_of_an_element(animals, search_for_index_of);
console.log(result);