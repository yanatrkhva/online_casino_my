
// for-in (iterates over keys(index of arrays))
// for-of (iterates over vaules(elements of arrays))




function find_index_of_an_element(animals_list, search_for_index_of) {
    for (let element of animals_list) {
    if (element["Player name"] === search_for_index_of) {
        return (animals_list.indexOf(element) + 1);
    } 
  } 
  return false;
}

const animals = {
    "Game rounds": [
      {
        "Player name": "Ni",
        "Player balance": 30,
        "Current timestamp": "2025-03-09T19:29:21.063Z"
      },
      {
        "Player name": "Love",
        "Player balance": 12,
        "Current timestamp": "2025-03-09T19:31:51.568Z"
      },
      {
        "Player name": "Michal",
        "Player balance": 9.5,
        "Current timestamp": "2025-03-10T20:03:31.262Z"
      },
      {
        "Player name": "Kiii",
        "Player balance": 9,
        "Current timestamp": "2025-03-10T19:16:41.956Z"
      },
      {
        "Player name": "Miiii",
        "Player balance": 8.5,
        "Current timestamp": "2025-03-09T19:29:58.999Z"
      }
    ]
  };

search_for_index_of = "Love1";

result = find_index_of_an_element(animals["Game rounds"], search_for_index_of);
console.log(result);