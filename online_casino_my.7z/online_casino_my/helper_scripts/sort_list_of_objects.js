
// reading json file
const fs = require('fs');
current_rank = require("./global_ranking.json"); 


// function sorting value of "Game rounds" key in current runk
function sort_ranking_by_player_balance(ranking) {
    return ranking.sort((a, b) => b["Player balance"] - a["Player balance"]);
    
}

// counting objects in array
function count_objects_in_array(ranking_object) {
   return amount_of_records = ranking_object.filter((item) => item && typeof item === "object" && !Array.isArray(item)).length; 
    
}

// reurn first 5 records from the array
function trim_list_to_defined_length(amount_of_records, ranking_object) {
    if (amount_of_records >= 5) {
    adjusted_ranking = ranking_object.slice(0, 5);
    return adjusted_ranking;
    }
    else {
    return ranking_object;
    }
}

function define_players_place()

const sorted_game_rounds = sort_ranking_by_player_balance(current_rank["Game rounds"]);
console.log(sorted_game_rounds);

count_objects_in_array(sorted_game_rounds);
console.log(amount_of_records);

trim_list_to_defined_length(amount_of_records, sorted_game_rounds);
console.log(adjusted_ranking);
