
function save_string_to_json_file(file_name, object_name, key_name_1, value_name_1, key_name_2, value_name_2) {
  
  const fs = require('fs');
  let data = {[object_name]: {[key_name_1]: value_name_1, [key_name_2]: value_name_2}};
  const jsonData = JSON.stringify(data, null, 2);

    fs.writeFile(file_name, jsonData + '\n', (err) => {
      if (err) {
      console.error('Error appending to the file:', err);
      } 
      else {
      console.log('Data was successfully appended!');
      }
      });
}

let object = 'cars';
let key_1 = 'big';
let value_1 = 'jeep';
let key_2 = 'small';
let value_2 = 'mini';
let json_file_name = 'dupa.json';

save_string_to_json_file(json_file_name, object, key_1, value_1, key_2, value_2);


