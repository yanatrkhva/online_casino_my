



function save_string_to_text_file(string_to_be_saved, file_name) {
  console.log('dupa1');
  const fs = require('fs');
  console.log('dupa2');

    fs.appendFile(file_name, string_to_be_saved + '\n', (err) => {
      if (err) {
      console.error('Error appending to the file:', err);
      } 
      else {
      console.log('Data was successfully appended!');
      }
      });
}

let string_data = 'Hello. It is me!';
let text_file_name = 'some_records.txt';

save_string_to_text_file(string_data, text_file_name);
