
// create another fucntion, which takes 2 arguments
// 1: big or small
// 2: car_model_name
// updates the json file, replacing value of car_model

// read the file
// update the data (in RAM memory)
// save the data to the updated_dupa.json file


function update_output(file_name, car_brand, bike_brand, plane_model, helicopter_model, boat_type, submarine_type, parameter) {
    const fs = require('fs');
    data = require("./input.json")
    console.log(`1st step testing:`);
    console.log(data);

    delete data.cars;

    data.michal = [parameter, "huge"];


    data.vehicles = {};
    data.vehicles.land = {};
    data.vehicles.land.car = car_brand;
    data.vehicles.land.bike = bike_brand;
    data.vehicles.air = {};
    data.vehicles.air.plane = plane_model;
    data.vehicles.air.helicopter = helicopter_model;
    data.vehicles.water = {};
    data.vehicles.water.boat = boat_type;
    data.vehicles.water.submarine = submarine_type;

    console.log(`2nd step testing:`);
    console.log(data);

    const jsonData = JSON.stringify(data, null, 2);
    fs.writeFile(file_name, jsonData, (err) => {
        if (err) {
        console.error('Error appending to the file:', err);
        } 
        else {
        console.log('Data was successfully appended!');
        }
        });
}

let parameter_name = 'very huge';
let car_mark = "bmw";
let bike_mark = "ducati";
let plane = "boeing";
let helicopter = "apache";
let boat = "yacht";
let submarine = "seawolf";


json_file_name = 'output.json'

update_output(json_file_name, car_mark, bike_mark, plane, helicopter, boat, submarine, parameter_name);



// read input 
// modify it as in updated output
// save data to output,json