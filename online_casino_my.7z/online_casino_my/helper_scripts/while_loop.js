

function find_index_of_an_element(list1, search_for_index_of) {
    let i = 0;
    let still_didnt_find_four = true;
    while (still_didnt_find_four) {
        let my_element = list1[i];
        if (my_element === search_for_index_of) {
            return i;
        }
        else {
            i++;
        }
        length_of_the_list = list1.length;
        if (i === length_of_the_list) {
            return false;
        }
    }
}

const animals = ["Lion", "Elephant", "Giraffe", "Zebra", "Kangaroo", "Panda", "Dolphin", "Wolf"];

search_for_index_of = "Wolf"

result = find_index_of_an_element(animals, search_for_index_of)
console.log(result)


// iterate over the list
// each time check if i index in list equals 4
// if not, continoue
// if yes, change still_didnt_find_four to false
// print i after the program exits the while loop 
