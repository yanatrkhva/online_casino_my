let name2 = "Yana";
// let number = 5;

const lista1 = [1, 2, 3, 4, 5];

for (let index in lista1) {
  console.log(`iteration number ${index}`);
  let output1 = name2.repeat(Number(index));
  let output1_length = output1.length; 

  let output2 = "Yana loves Michal fuck";
  let output2_length = output2.length;

if (index == 3) {
  if (output2_length > 9) {
     output2 = output2.slice(0, 9);
     output2_length = output2.length;
  }

  console.log(output2);
  console.log(`output length is: ${output2_length}`);
  }

else {
  if (output1_length > 9) {
    output1 = output1.slice(0, 9);
    output1_length = output1.length;
 }

  console.log(output1);
  console.log(`output length is: ${output1_length}`);
  }
}


