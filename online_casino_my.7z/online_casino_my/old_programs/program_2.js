// ask user to input number $lotteries_number
// then run the lottery $lotteries_number numbers

// for each lottery run:
// check if name is "yana"
// if yes, then check if wakacje_panstwo is different than telesnica
// if yes, then modify the log, adding the following string "only if she will be learning js every fucking day"

let imiona = ["michal", "yana", "dzumu", "rudy", "lida"]
let wakacje = ["azja", "usa", "brazil", "telesnica", "minsk"]

const readline = require("readline-sync");
let lotteries_number = Number(readline.question("Enter your number:"));

let count = 0;
while (count < lotteries_number) {
    let random_number_1 = Math.floor(Math.random() * 5);
    let random_number_2 = Math.floor(Math.random() * 5);

    let imie = imiona[random_number_1]; 
    let wakacje_panstwo = wakacje[random_number_2];
    let output = (`${imie} pojedzie w tym roku na wakacje do ${wakacje_panstwo}`);
    let output_upgrade = (`only if she will be learning js every fucking day`)

    if (imie == "yana") {
        if (wakacje_panstwo != "telesnica") {
            output = output + output_upgrade;
        }
    };
    
    console.log(output);

    count++;
}