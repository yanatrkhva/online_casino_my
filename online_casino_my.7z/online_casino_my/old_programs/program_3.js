
//Write a program that asks the user for two numbers and then displays their sum, difference, product, and quotient.

const readline = require("readline-sync");
let first_number = Number(readline.question("Enter first number: "));
let second_number = Number(readline.question("Enter second number: "));

let sum = first_number + second_number;
let difference = first_number - second_number;
let product = first_number * second_number;
let quotient = first_number / second_number; 

console.log(`Sum: ${sum}`);
console.log(`Difference: ${difference}`);
console.log(`Product: ${product}`);
console.log(`Quotient: ${quotient}`);


