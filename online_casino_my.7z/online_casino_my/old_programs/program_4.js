//Task:
// Write a program that asks the user for a number.

// If the number is greater than 10, display "The number is greater than 10."
// If it is less than 10, display "The number is less than 10."
// If it is exactly 10, display "The number is exactly 10."

const readline = require("readline-sync");
let new_number = Number(readline.question("Enter the number: "));

if (new_number > 10) {
    console.log(`The number is greater than 10.`);
}

else if (new_number < 10) {
    console.log(`The number is less than 10.`);
}

else {
    console.log(`The number is exactly 10.`);
}