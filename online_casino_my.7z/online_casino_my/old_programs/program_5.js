// update the function to take two arguments
// the function must print argument1 and argument2
// then the function must return argument1 multiplied by argument2
// then the program invokes the function and assigns its result to the variable $multiplied_aninal
// then the program must print the $multiplied_aninal variable

function print_animal(argument1, argument2) {
    console.log(argument1);
    console.log(argument2);

    let multiplied = argument1.repeat(Number(argument2));
    return multiplied;
}


const readline = require("readline-sync");
let animal = readline.question("Animal: ");
let multiplication = Number(readline.question("How many times: "));


multiplied_animal = print_animal(animal, multiplication);
console.log(multiplied_animal);
