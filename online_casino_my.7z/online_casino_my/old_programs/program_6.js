// 

function print_animal(argument1, argument2) {
    console.log(argument1);
    console.log(argument2);

    let multiplied = argument1.repeat(Number(argument2));
    return multiplied;
}

function analyze_string(argument1) {
    let output_length = argument1.length;
    let a_letters = argument1.split('a').length - 1;

    console.log(output_length);
    return a_letters;
}

const readline = require("readline-sync");
let animal = readline.question("Animal: ");
let multiplication = Number(readline.question("How many times: "));

multiplied_animal = print_animal(animal, multiplication);
console.log(multiplied_animal);

analyze_final = analyze_string(multiplied_animal);
console.log(analyze_final);
